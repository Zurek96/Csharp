﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace SendGridApi2.Models
{
    public class SendGridApi2Context : DbContext
    {
        public SendGridApi2Context (DbContextOptions<SendGridApi2Context> options)
            : base(options)
        {
        }

        public DbSet<DataReceived> DataReceived { get; set; }
    }
}
