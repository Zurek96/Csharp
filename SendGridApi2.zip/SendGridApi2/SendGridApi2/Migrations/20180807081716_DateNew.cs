﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SendGridApi2.Migrations
{
    public partial class DateNew : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Date",
                table: "DataReceived",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Date",
                table: "DataReceived");
        }
    }
}
