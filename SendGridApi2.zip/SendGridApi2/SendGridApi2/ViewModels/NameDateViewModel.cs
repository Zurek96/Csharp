﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;

namespace SendGridApi2.Models
{
    public class NameDateViewModel
    {
        public List<DataReceived> Data;
        public SelectList Months;
        public string Month { get; set; }
        public string SearchString { get; set; }
    }
}
