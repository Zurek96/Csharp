﻿using System.Collections.Generic;
using SendGridApi2.Models;

namespace SendGridApi2.ViewModels
{
    public class ChartViewModel : NameDateViewModel
    {
        public Dictionary<string, int> Counter;

    }
}
