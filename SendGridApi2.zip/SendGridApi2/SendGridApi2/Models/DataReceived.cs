﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace SendGridApi2.Models
{
    public class DataReceived
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string FromAddress { get; set; }
        public string ToAddress { get; set; }
        public DateTimeOffset DateSent { get; set; }
        public int Date { get; set; }
        public string Event { get; set; }

    }
}
